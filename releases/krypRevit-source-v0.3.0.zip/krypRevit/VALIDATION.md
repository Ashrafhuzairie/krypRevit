# krypRevit 0.3.0 validation

Executed on Linux on 2026-10-30.

- Release build against .NET Framework 4.8 and RevitAPI/RevitAPIUI 24.0: passed, zero compiler warnings/errors.
- Native chat source compiled in the production DLL: ChatForm, ShowChatCommand, ProviderClient, RevitChatTools, ChatRunner and Windows-user DPAPI key storage.
- `dotnet run --project tests/ChatHarness/ChatHarness.csproj -c Release`: **14 checks passed**. Production chat/provider source is linked with a test JSON adapter and mocked HTTP/Revit tool dispatch; no provider network requests or model edits are made.
- Chat checks cover native OpenAI tool replies, Claude parallel tool-result grouping, Gemini function signatures/results, keys in proper headers, numeric/text action normalization, rejected unregistered apply tools, invalid/oversized proposals, redacted provider failures, cancellation, failed-exchange recovery, document-context changes, empty answers and tool-loop limits.
- `python -m unittest discover -s tests -v` with KRYPREVIT_DOTNET set: **23 tests passed**, including MCP stdio integration and actual production C# TCP/HTTP transport hosted under .NET 8 with substituted endpoints.
- Release entry point, built-in chat command/types, .NET Framework target, Revit 24 references and four embedded icon hashes: checked.
- Repeat Release rebuild: identical DLL SHA-256.
- Original Microsoft SDK download SHA-512 matched official release metadata. NuGet signature verification exited 0 without disabling checks, with NU3018/NU3028 warnings because certificate-revocation endpoints were unavailable; revocation status remains unconfirmed. Build references are not bundled.

Not executed: Windows Forms interaction/layout, WPF icon rendering, DPAPI key save/load on Windows, real provider API accounts, Revit startup, native dialog review, model actions, transaction rollback and Undo. Compilation and mocked protocol checks do not establish those runtime behaviors. See REVIT-VALIDATION.md.

The built-in chat is new source code implementing the previously missing UI and provider workflow; it is not a recovered/decompiled copy of the newer uploaded DLL. It supports the documented general model actions, not the absent automatic SEM opening-planner implementation. Python/external MCP clients are optional for built-in chat.
