using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace krypRevit.Addin.Endpoints
{
    public sealed class EditAction
    {
        public string operation { get; set; }
        public string unique_id { get; set; }
        public string parameter_id { get; set; }
        public object value { get; set; }
        public double[] vector_ft { get; set; }
        public double[] origin_ft { get; set; }
        public double[] axis { get; set; }
        public double angle_radians { get; set; }
        public string wall_type_unique_id { get; set; }
        public string level_unique_id { get; set; }
        public double[] start_ft { get; set; }
        public double[] end_ft { get; set; }
        public double height_ft { get; set; }
    }
    public sealed class PlanRequest { public List<EditAction> actions { get; set; } }
    public static class Plans
    {
        private sealed class Plan
        {
            public string Id = Guid.NewGuid().ToString("N");
            public Document Document;
            public long Revision;
            public DateTime Expires = DateTime.UtcNow.AddMinutes(10);
            public List<EditAction> Actions;
            public string[] Summary;
            public string State = "pending_review";
            public string Error;
            public string[] Created = new string[0];
        }
        private static Plan current;
        private static long revision;
        public static void DocumentChanged() { Interlocked.Increment(ref revision); }
        public static void Clear() { current = null; }
        private static double Number(object value)
        {
            if (!(value is double || value is float || value is int || value is long || value is decimal))
                throw new ArgumentException("Numeric values must be JSON numbers.");
            var n = Convert.ToDouble(value, CultureInfo.InvariantCulture);
            if (double.IsNaN(n) || double.IsInfinity(n) || Math.Abs(n) > 1000000)
                throw new ArgumentException("Number must be finite and within +/- 1,000,000.");
            return n;
        }
        private static XYZ Point(double[] value)
        {
            if (value == null || value.Length != 3) throw new ArgumentException("Expected three coordinates.");
            foreach (var n in value) Number(n);
            return new XYZ(value[0], value[1], value[2]);
        }
        private static Parameter Parameter(Element e, EditAction a)
        {
            long id;
            if (!long.TryParse(a.parameter_id, out id)) throw new ArgumentException("Use parameter_id returned by inspect_element.");
            var p = e.Parameters.Cast<Parameter>().SingleOrDefault(x => x.Id.Value == id);
            if (p == null || p.IsReadOnly) throw new ArgumentException("Parameter missing or read-only.");
            if (p.StorageType == StorageType.String)
            {
                if (!(a.value is string) || ((string)a.value).Length > 2000) throw new ArgumentException("Expected text, at most 2000 characters.");
            }
            else if (p.StorageType == StorageType.Double) Number(a.value);
            else if (p.StorageType == StorageType.Integer)
            {
                var n = Number(a.value);
                if (n != Math.Truncate(n) || n < int.MinValue || n > int.MaxValue) throw new ArgumentException("Expected an integer.");
                if (p.Definition.GetDataType() == SpecTypeId.Boolean.YesNo && n != 0 && n != 1) throw new ArgumentException("Yes/no values must be 0 or 1.");
            }
            else throw new ArgumentException("Only text, integer and double parameters can be edited.");
            return p;
        }
        private static string Describe(Document doc, EditAction a)
        {
            if (a.operation == "create_wall")
            {
                var type = Model.Element(doc, a.wall_type_unique_id) as WallType;
                var level = Model.Element(doc, a.level_unique_id) as Level;
                if (type == null || type.Kind != WallKind.Basic || level == null) throw new ArgumentException("Choose a basic wall type and level from inspect_model.");
                var start = Point(a.start_ft); var end = Point(a.end_ft);
                if (Math.Abs(start.Z - end.Z) > 1e-6 || Math.Abs(start.Z - level.Elevation) > 1e-6)
                    throw new ArgumentException("Wall endpoints must lie on the selected level elevation.");
                if (start.DistanceTo(end) < doc.Application.ShortCurveTolerance) throw new ArgumentException("Wall is too short.");
                if (Number(a.height_ft) <= 0 || a.height_ft > 30000) throw new ArgumentException("Wall height must be positive and at most 30,000 feet.");
                return $"CREATE basic wall '{type.Name}', level '{level.Name}', from {Json.Serialize(a.start_ft)} to {Json.Serialize(a.end_ft)} ft, height {a.height_ft} ft, nonstructural, unflipped, zero offset.";
            }
            var e = Model.Element(doc, a.unique_id);
            if (e is ElementType || e is RevitLinkInstance || e.Pinned || e.GroupId != ElementId.InvalidElementId)
                throw new ArgumentException("Type elements, links, pinned and grouped elements cannot be edited by these tools.");
            var label = $"{e.Name} [id {e.Id.Value}, {e.UniqueId}]";
            switch (a.operation)
            {
                case "set_parameter":
                    var p = Parameter(e, a);
                    return $"SET {label}: {p.Definition.Name} ({a.parameter_id}, {p.StorageType}, spec {p.Definition.GetDataType().TypeId}) from {Json.Serialize(Model.Value(p))} to {Json.Serialize(a.value)}. Doubles use Revit internal units.";
                case "move": case "copy":
                    var v = Point(a.vector_ft);
                    if (v.GetLength() < 1e-9) throw new ArgumentException("Translation must be nonzero.");
                    return $"{a.operation.ToUpperInvariant()} {label} by {Json.Serialize(a.vector_ft)} feet. Copy may include dependent elements.";
                case "rotate":
                    Point(a.origin_ft);
                    if (Point(a.axis).GetLength() < 1e-9) throw new ArgumentException("Rotation axis must be nonzero.");
                    if (Math.Abs(Number(a.angle_radians)) > 2 * Math.PI || Math.Abs(a.angle_radians) < 1e-9) throw new ArgumentException("Rotation must be nonzero and within +/- 2 pi radians.");
                    return $"ROTATE {label} by {a.angle_radians} radians around {Json.Serialize(a.origin_ft)} ft, axis {Json.Serialize(a.axis)}.";
                default: throw new ArgumentException("Unsupported operation. Use set_parameter, move, rotate, copy or create_wall.");
            }
        }
        private static void Refresh()
        {
            if (current != null && current.State == "pending_review" &&
                (current.Expires <= DateTime.UtcNow || current.Revision != Interlocked.Read(ref revision)))
                current.State = "stale";
        }
        public static string Propose(UIApplication app, string json)
        {
            Refresh();
            if (current != null && current.State == "pending_review") throw new InvalidOperationException("A plan awaits review. Review or cancel it inside Revit first.");
            var doc = Model.Document(app);
            var request = Json.Deserialize<PlanRequest>(json);
            if (request?.actions == null || request.actions.Count == 0 || request.actions.Count > 10)
                throw new ArgumentException("Supply between 1 and 10 actions.");
            if (request.actions.Any(a => a == null)) throw new ArgumentException("Actions cannot be null.");
            // Disallow two operations on the same target; each preview must describe the actual pre-state.
            var ids = request.actions.Where(a => a.operation != "create_wall").Select(a => a.unique_id).ToArray();
            if (ids.Distinct().Count() != ids.Length) throw new ArgumentException("Use only one action per element in a plan.");
            var summary = request.actions.Select(a => Describe(doc, a)).ToArray();
            current = new Plan { Document = doc, Revision = Interlocked.Read(ref revision), Actions = request.actions, Summary = summary };
            return Status();
        }
        public static string Status()
        {
            Refresh();
            if (current == null) return Json.Serialize(new { ok = true, state = "none" });
            return Json.Serialize(new { ok = true, plan_id=current.Id, state=current.State, document=current.Document.IsValidObject ? current.Document.Title : null,
                expires_utc=current.Expires.ToString("o"), summary=current.Summary, error=current.Error, created_unique_ids=current.Created,
                next_step=current.State == "pending_review" ? "In Revit, click krypRevit > Review actions. No model changes have been made." : null });
        }
        public static void Review(UIApplication app)
        {
            Refresh();
            var plan = current;
            if (plan == null || plan.State != "pending_review") { TaskDialog.Show("krypRevit", "No pending plan. Request a new proposal if the previous plan is stale."); return; }
            var doc = Model.Document(app);
            if (!ReferenceEquals(doc, plan.Document)) throw new InvalidOperationException("Switch back to the document used to propose this plan.");
            var dialog = new TaskDialog("krypRevit — review model changes") {
                MainInstruction = $"Review {plan.Actions.Count} action(s) in {doc.Title}",
                MainContent = string.Join("\n\n", plan.Summary.Select((s,i) => $"{i+1}. {s}")) + "\n\nRevit may adjust dependent or joined geometry. All changes are one undo step. Test on a copy first.",
                CommonButtons = TaskDialogCommonButtons.Cancel, DefaultButton = TaskDialogResult.Cancel
            };
            dialog.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Approve and apply these actions");
            if (dialog.Show() != TaskDialogResult.CommandLink1) { plan.State = "cancelled"; return; }
            Refresh();
            if (plan.State != "pending_review" || !ReferenceEquals(app.ActiveUIDocument?.Document, doc)) throw new InvalidOperationException("Plan expired or document changed. Propose again.");
            plan.State = "applying";
            try
            {
                foreach (var a in plan.Actions) Describe(doc, a);
                var created = new List<string>();
                using (var tx = new Transaction(doc, "krypRevit reviewed actions"))
                {
                    if (tx.Start() != TransactionStatus.Started) throw new InvalidOperationException("Could not start transaction.");
                    var options = tx.GetFailureHandlingOptions().SetFailuresPreprocessor(new RollbackFailures()).SetClearAfterRollback(true);
                    tx.SetFailureHandlingOptions(options);
                    foreach (var a in plan.Actions)
                    {
                        if (a.operation == "create_wall")
                        {
                            var wall = Wall.Create(doc, Line.CreateBound(Point(a.start_ft), Point(a.end_ft)), Model.Element(doc,a.wall_type_unique_id).Id,
                                Model.Element(doc,a.level_unique_id).Id, a.height_ft, 0, false, false);
                            created.Add(wall.UniqueId); continue;
                        }
                        var e = Model.Element(doc, a.unique_id);
                        switch (a.operation)
                        {
                            case "set_parameter":
                                var p = Parameter(e,a); bool changed;
                                if (p.StorageType == StorageType.String) changed = p.Set((string)a.value);
                                else if (p.StorageType == StorageType.Integer) changed = p.Set((int)Number(a.value));
                                else changed = p.Set(Number(a.value));
                                if (!changed) throw new InvalidOperationException("Revit refused parameter change.");
                                break;
                            case "move": ElementTransformUtils.MoveElement(doc,e.Id,Point(a.vector_ft)); break;
                            case "rotate": ElementTransformUtils.RotateElement(doc,e.Id,Line.CreateUnbound(Point(a.origin_ft),Point(a.axis).Normalize()),a.angle_radians); break;
                            case "copy":
                                foreach (var id in ElementTransformUtils.CopyElement(doc,e.Id,Point(a.vector_ft))) created.Add(doc.GetElement(id).UniqueId);
                                break;
                        }
                    }
                    if (tx.Commit() != TransactionStatus.Committed) throw new InvalidOperationException("Revit rolled back the batch because it produced a warning or error. Inspect constraints/ownership and propose a corrected plan.");
                }
                plan.Created = created.ToArray(); plan.State = "applied";
                TaskDialog.Show("krypRevit", "Actions committed. Use Revit Undo to undo the entire batch.");
            }
            catch (Exception ex)
            {
                plan.State = "failed"; plan.Error = ex.Message;
                TaskDialog.Show("krypRevit", "Batch was not committed:\n" + ex.Message);
            }
        }
        private sealed class RollbackFailures : IFailuresPreprocessor
        {
            public FailureProcessingResult PreprocessFailures(FailuresAccessor failures) =>
                failures.GetFailureMessages().Count > 0 ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }
}
