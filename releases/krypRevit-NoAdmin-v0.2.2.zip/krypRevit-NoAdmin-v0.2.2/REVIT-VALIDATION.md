# Windows/Revit 2024 runtime validation — NOT EXECUTED

Install the packaged Release DLL (or rebuild against the installed Revit 2024 API with .NET Framework 4.8), then run these checks on a saved disposable copy of a project. Record failures and exact Revit build before wider use.

1. Ensure old versions are disabled. Verify startup under a standard Windows account without a URL-ACL reservation, ribbon branding and transparent green crystal icons on both buttons in small/large ribbon layouts and light/dark themes, MCP Status, health and selected-element inspection. Verify the wall/type/level IDs refer to the current model.
2. Propose a text parameter edit. Inspect the old/new value in Review actions. Cancel: verify the model is unchanged and status is cancelled. Resubmit and approve: verify the parameter changed, status is applied, and one Revit Undo restores it.
3. Test integer and double parameters, including yes/no 0/1 and known unit conversions. Reject read-only, unsupported ElementId, malformed, nonfinite, missing and out-of-range values without changes.
4. Test a move, rotation and copy individually with known coordinates; verify geometry, returned created IDs, Undo and dependent elements. Check pinned, grouped, type and linked elements are rejected.
5. Create a basic wall with valid level/type IDs and endpoints at the level elevation; verify dimensions and Undo. Test wrong type/level, nonhorizontal endpoints, too-short line and invalid height.
6. Test multiple actions on different elements. Force a later action to fail (for example a constrained move that fails at commit): verify NONE of the batch commits and status reports failed. Verify both warnings and errors roll back. Check worksharing ownership and constrained elements.
7. Propose then edit the model manually or use Undo/Redo: verify the proposal becomes stale and cannot execute. Switch documents: verify it cannot apply to the wrong document. Close/reopen the target model: verify the previous plan is not applicable. After ten minutes, require a new proposal.
8. Verify a pending plan cannot be replaced over HTTP. Review/cancel it first. Verify one action per target and the ten-action limit. Test an empty proposal and unknown operation.
9. Keep Revit busy for longer than the queue timeout, then return to idle. Verify an expired queued proposal never stages later. Query status before retrying. Shut down Revit with requests queued: verify clients terminate and no edits occur.
10. Confirm browser-origin requests and unmarked requests are rejected, GET cannot create a proposal, and there is no HTTP/MCP apply route. Stop/restart Revit and the MCP client; check state is cleared and tools reconnect.

Do not report these checks as passed based on Python mock results. The built-in provider chat and SEM opening workflow from the newer supplied DLL are not present in this first-version source upgrade.
