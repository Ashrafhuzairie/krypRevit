using System;
using System.Linq;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
namespace krypRevit.Addin.Endpoints
{
    public static class Model
    {
        public static Document Document(UIApplication app)
        {
            var doc = app.ActiveUIDocument?.Document;
            if (doc == null || doc.IsFamilyDocument || doc.IsReadOnly || doc.IsModifiable)
                throw new InvalidOperationException("Open an editable project document with no active transaction.");
            return doc;
        }
        public static Element Element(Document doc, string uid)
        {
            if (string.IsNullOrWhiteSpace(uid)) throw new ArgumentException("An element unique_id is required.");
            return doc.GetElement(uid) ?? throw new ArgumentException("Element no longer exists: " + uid);
        }
        public static string Run(UIApplication app, string uid, int limit)
        {
            var doc = Document(app);
            if (!string.IsNullOrWhiteSpace(uid))
            {
                var e = Element(doc, uid);
                var parameters = e.Parameters.Cast<Parameter>().Select(p => new {
                    parameter_id = p.Id.Value.ToString(System.Globalization.CultureInfo.InvariantCulture), name = p.Definition.Name,
                    storage = p.StorageType.ToString(), read_only = p.IsReadOnly,
                    value = Value(p), display = p.AsValueString(),
                    data_type = p.Definition.GetDataType().TypeId
                }).ToArray();
                return Json.Serialize(new { ok = true, element = Describe(e), parameters });
            }
            var selected = app.ActiveUIDocument.Selection.GetElementIds();
            IEnumerable<Element> elements = selected.Count > 0 ? selected.Select(id => doc.GetElement(id)) :
                new FilteredElementCollector(doc).WhereElementIsNotElementType().WhereElementIsViewIndependent().Cast<Element>();
            return Json.Serialize(new { ok = true, scope = selected.Count > 0 ? "selection" : "model", limit,
                elements = elements.Take(limit).Select(Describe).ToArray(),
                levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().Select(e => new { unique_id=e.UniqueId, name=e.Name, elevation_ft=e.Elevation }).ToArray(),
                wall_types = new FilteredElementCollector(doc).OfClass(typeof(WallType)).Cast<WallType>().Where(t => t.Kind == WallKind.Basic).Select(t => new { unique_id=t.UniqueId, name=t.Name }).ToArray() });
        }
        public static object Describe(Element e) => new { unique_id=e.UniqueId, id=e.Id.Value.ToString(), name=e.Name,
            category=e.Category?.Name, type_unique_id=e.Document.GetElement(e.GetTypeId())?.UniqueId, pinned=e.Pinned };
        public static object Value(Parameter p)
        {
            if (!p.HasValue) return null;
            switch (p.StorageType)
            {
                case StorageType.String: return p.AsString();
                case StorageType.Integer: return p.AsInteger();
                case StorageType.Double: return p.AsDouble();
                case StorageType.ElementId: return p.AsElementId().Value.ToString();
                default: return null;
            }
        }
    }
}
