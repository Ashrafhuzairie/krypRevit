# Validation record

Executed in Linux on 2026-10-30 with Python 3.12.14, MCP 1.30.0 and httpx 0.28.1.

- `python -m unittest discover -s tests -v`: **23 tests passed**, including a real MCP stdio session against a localhost contract fixture and 12 tests of production HttpServer.cs hosted under .NET 8 with substituted Revit dispatch/endpoints. The latter exercise real TCP/HTTP request parsing and responses, not Revit behavior. The initial sandboxed run could not create sockets; the full rerun with localhost access passed all 23 tests.
- `python -m compileall -q mcp_server tests`: passed.
- `python -m pip check`: passed, no broken requirements.
- Release C# build: **passed, zero warnings and zero errors**, using Microsoft .NET SDK 8.0.427/MSBuild 17.11, .NET Framework 4.8 reference assemblies 1.0.3, and Nice3point RevitAPI/RevitAPIUI 2024.0.0 compile-time reference packages from NuGet.org.
- Repeat Release rebuild: **identical DLL SHA-256**.
- PE/assembly metadata: .NET Framework 4.8; RevitAPI/RevitAPIUI 24.0.0.0; krypRevit.Addin 0.2.2.0; entry point/review command present; AnyCPU IL-only without a 32-bit requirement.
- Microsoft SDK archive SHA-512 matched the official release metadata. NuGet package signature verification exited 0 without disabling checks, but reported NU3018/NU3028 certificate-revocation-unavailable warnings; revocation status remains unconfirmed.
- Manifest/project XML, compile-item paths, assembly/namespace branding consistency: checked.
- `mcp_server/requirements-tested.txt`: installed package versions from this run. `requirements.txt` retains the supplied broad dependency constraints; the tested versions file is available for reproducible Python installation.

Not run: PowerShell installation on Windows, Revit loading, parameter writes, geometry operations, review dialog, document invalidation, timeout behavior of the native bridge, transaction rollback or Undo. Revit 2024 is unavailable on this Linux host. Python mock tests and compilation do not establish that these work. Complete REVIT-VALIDATION.md before using on working models.

No source from the newer compiled DLL was recovered or merged; this code is based on the uploaded first version. The rebuilt release includes the compiled DLL and portable PDB; no changes have been pushed to GitHub.

Version 0.2.1 replaces Windows HttpListener/HTTP.sys with a bounded loopback TcpListener, removing the need for an administrator-created HTTP URL ACL. The no-admin package is intended for manual copying into the Windows user's standard Revit Addins folder; company permission to load custom add-ins is still required. The no-admin manifest uses the username from the original uploaded manifest and must be adjusted if the destination DLL path differs.

Version 0.2.2 adds the embedded transparent crystal icon to both ribbon buttons, using 16/32-pixel WPF bitmap decoding. The Release DLL compiled with zero warnings/errors; its embedded PNG resource matches the master PNG SHA-256, and the master image alpha range is 0–255. The 23 previous MCP/transport test results apply to the unchanged MCP and transport code; they were not rerun for this visual change. Actual WPF icon decoding/rendering and Revit startup remain untested on Windows.
